# NSW CARE — Google Sheets Cloud Save

โปรเจกต์นี้เพิ่มการบันทึกข้อมูลส่วนกลางของ NSW CARE ลง Google Sheets ผ่าน Google Apps Script

## 1) สร้าง Apps Script

เปิด Google Sheets ที่ต้องการใช้เป็นฐานข้อมูล แล้วไปที่:

Extensions → Apps Script

ลบโค้ดเดิม แล้วคัดลอก `google-apps-script/Code.gs` ทั้งหมดไปวาง

จากนั้น:
Deploy → New deployment → Web app

- Execute as: Me
- Who has access: Anyone

คัดลอก URL ที่ลงท้ายด้วย `/exec`

## 2) URL ที่ตั้งไว้ในเว็บ

ไฟล์ `src/utils/cloudSync.ts` มี URL Apps Script ของโปรเจกต์ไว้แล้ว

ถ้าต้องการเปลี่ยน ให้แก้ `DEFAULT_APPS_SCRIPT_URL` หรือกำหนด Vercel Environment Variable:

`VITE_APPS_SCRIPT_URL=https://script.google.com/macros/s/XXXXX/exec`

## 3) สิ่งที่ถูกบันทึก

เว็บจะบันทึกข้อมูลส่วนกลางของระบบ ได้แก่:

- Users
- Students
- Assignments
- Submissions
- Attendance
- Subjects
- AppState

และบันทึกกิจกรรม Login / Register / Logout ลง `ActivityLog`

`currentUser` และแท็บที่เปิดอยู่จะยังเป็นข้อมูลเฉพาะเบราว์เซอร์ ไม่เก็บเป็น session กลาง เพื่อไม่ให้ผู้ใช้คนหนึ่งกลายเป็นผู้ใช้ของทุกคน

## 4) การทำงาน

เมื่อเว็บโหลด:
1. โหลดข้อมูลส่วนกลางจาก Apps Script
2. ถ้ามีข้อมูลใน Google Sheets จะนำมาแสดง
3. ถ้ายังไม่มี จะใช้ข้อมูลเริ่มต้นของโปรเจกต์
4. เมื่อมีการเพิ่ม/แก้ไข/ลบข้อมูล ระบบจะส่ง state ล่าสุดไป Apps Script โดยอัตโนมัติ
5. Apps Script จะอัปเดตตารางแยกให้ด้วย

## 5) ทดสอบ API

เปิด:

`YOUR_EXEC_URL?action=getState`

หรือ:

`YOUR_EXEC_URL?action=ping`

ถ้าทำงานจะเห็น JSON
